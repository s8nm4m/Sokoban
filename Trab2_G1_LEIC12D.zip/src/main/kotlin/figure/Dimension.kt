package figure

data class Dimension(val width: Int, val height: Int)